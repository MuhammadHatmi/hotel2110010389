/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dataTable;
import java.util.ArrayList;

/**
 *
 * @author ACER
 */
public class dataChekout {
    private  ArrayList<Integer> notacheckout;
    private  ArrayList<Integer> noreg;
    private  ArrayList<Integer> tglcheckout;
    private  ArrayList<Integer> jamcheckout;
    private  ArrayList<String> lminap;
    private  ArrayList<Integer> uangmuka;
    private  ArrayList<Integer> totalbayar;

    public dataChekout(){
        
        notacheckout = new ArrayList<Integer>();
        noreg = new ArrayList<Integer>();
        tglcheckout = new ArrayList<Integer>();
        jamcheckout = new ArrayList<Integer>();
        lminap = new ArrayList<String>();
        uangmuka = new ArrayList<Integer>();
        totalbayar = new ArrayList<Integer>();
        
    }
    
    public void insertNotacheckout(Integer isi){
        this.notacheckout.add(isi);
    }
    
    public ArrayList<Integer> getRecordNotacheckout(){
        return this.notacheckout;
    }
    
    public void insertNoreg (Integer isi){
        this.noreg.add(isi);
    }
    
    public ArrayList<Integer> getRecordNoreg(){
        return this.noreg;
    }
    
    public void insertTglcheckout(Integer isi){
        this.tglcheckout.add(isi);
    }
    
    public ArrayList<Integer> getRecordTglcheckout(){
        return this.tglcheckout;
    }
    
    public void insertJamcheckout (Integer isi){
        this.jamcheckout.add(isi);
    }
    
    public ArrayList<Integer> getRecordJamcheckout(){
        return this.jamcheckout;
    }
    
    public void insertLminap (String isi){
        this.lminap.add(isi);
    }
    
    public ArrayList<String> getRecordLminap(){
        return this.lminap;
    }
    
    public void insertUangmuka (Integer isi){
        this.uangmuka.add(isi);
    }
    
    public ArrayList<Integer> getRecordUangmuka(){
        return this.uangmuka;
    }
    
     public void insertTotalbayar (Integer isi){
        this.totalbayar.add(isi);
    }
    
    public ArrayList<Integer> getRecordTotalbayar(){
        return this.totalbayar;
    }
    
}