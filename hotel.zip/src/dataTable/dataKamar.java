/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dataTable;
import java.util.ArrayList;
/**
 *
 * @author ACER
 */
public class dataKamar {
    
    private  ArrayList<Integer> nokamar;
    private  ArrayList<Integer> jeniskamar;
    private  ArrayList<Integer> typekamar;
    private  ArrayList<String> sttskamar;
    

    public dataKamar(){
        
        nokamar = new ArrayList<Integer>();
        jeniskamar = new ArrayList<Integer>();
        typekamar = new ArrayList<Integer>();
        sttskamar = new ArrayList<String>();
    }
    
    public void insertNokamar(Integer isi){
        this.nokamar.add(isi);
    }
    
    public ArrayList<Integer> getRecordNokamar(){
        return this.nokamar;
    }
    
    public void insertJeniskamar(Integer isi){
        this.jeniskamar.add(isi);
    }
    
    public ArrayList<Integer> getRecordJeniskamar(){
        return this.jeniskamar;
    }
      
    public void insertTypekamar(Integer isi){
        this.typekamar.add(isi);
    }
    
    public ArrayList<Integer> getRecordTypekmar(){
        return this.typekamar;
    }
    
     public void insertSttskamar(String isi){
        this.sttskamar.add(isi);
    }
    
    public ArrayList<String> getRecordSttskamar(){
        return this.sttskamar;
    }
    

}

