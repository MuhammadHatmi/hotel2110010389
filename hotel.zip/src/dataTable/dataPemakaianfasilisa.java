   /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dataTable;

import java.util.ArrayList;

/**
 *
 * @author ACER
 */
public class dataPemakaianfasilisa {
 
    private  ArrayList<Integer> noreg;
    private  ArrayList<String> kategori;
    private  ArrayList<String> fasilitas;
    private  ArrayList<Integer> tarif;
   

    public dataPemakaianfasilisa(){
        
        noreg = new ArrayList<Integer>();
        kategori = new ArrayList<String>();
        fasilitas = new ArrayList<String>();
        tarif = new ArrayList<Integer>();
        
    }
    
    public void insertNoreg(Integer isi){
        this.noreg.add(isi);
    }
    
    public ArrayList<Integer> getRecordNoreg(){
        return this.noreg;
    }
    
    public void insertKategori (String isi){
        this.kategori.add(isi);
    }
    
    public ArrayList<String> getRecordKategori(){
        return this.kategori;
    }
    public void insertFasilitas (String isi){
        this.fasilitas.add(isi);
    }
    
    public ArrayList<String> getRecordFasilitas(){
        return this.fasilitas;
    }
    public void insertTarif (Integer isi){
        this.tarif.add(isi);
    }
    
    public ArrayList<Integer> getRecordTarif(){
        return this.tarif;
    }
    
}


