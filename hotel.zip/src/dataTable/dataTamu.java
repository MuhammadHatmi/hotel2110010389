/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dataTable;
import java.util.ArrayList;
/**
 *
 * @author ACER
 */
public class dataTamu {
  
    private  ArrayList<Integer> notamu;
    private  ArrayList<String> namatamu;
    private  ArrayList<String> pekerjaan;
    private  ArrayList<String> alamat;
   

    public dataTamu(){
        
        notamu = new ArrayList<Integer>();
        namatamu = new ArrayList<String>();
        pekerjaan= new ArrayList<String>();
        alamat = new ArrayList<String>();
       
        
     }
    
    public void insertNotamu (Integer isi){
        this.notamu.add(isi);
    }
    
    public ArrayList<Integer> getRecordNotamu(){
        return this.notamu;
    }
    
    public void insertNamatamu (String isi){
        this.namatamu.add(isi);
    }
    
    public ArrayList<String> getRecordNamatamu(){
        return this.namatamu;
    }
   
    public void insertPekerjaan (String isi){
        this.pekerjaan.add(isi);
    }
    
    public ArrayList<String> getRecordPekerjaan(){
        return this.pekerjaan;
    }
    
    public void insertAlamat (String isi){
        this.alamat.add(isi);
    }
    
    public ArrayList<String> getRecordAlamat(){
        return this.alamat;
    }
    
}

