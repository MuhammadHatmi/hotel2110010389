/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dataTable;
import java.util.ArrayList;

/**
 *
 * @author ACER
 */
public class dataPemesanan {
    
    private  ArrayList<Integer> nopesan;
    private  ArrayList<Integer> nokamar;
    private  ArrayList<String> tglpesan;
    private  ArrayList<Integer> uangmuka;

    public dataPemesanan(){
        
        nopesan = new ArrayList<Integer>();
        nokamar = new ArrayList<Integer>();
        tglpesan = new ArrayList<String>();
        uangmuka = new ArrayList<Integer>();
        
    }
    
    public void insertNopsan(Integer isi){
        this.nopesan.add(isi);
    }
    
    public ArrayList<Integer> getRecordNopesan(){
        return this.nopesan;
    }
    
    public void insertNokamar (Integer isi){
        this.nokamar.add(isi);
    }
    
    public ArrayList<Integer> getRecordNokamar(){
        return this.nokamar;
    }
   
    public void insertTglpesan (String isi){
        this.tglpesan.add(isi);
    }
    
    public ArrayList<String> getRecordTglpesan(){
        return this.tglpesan;
    }
    
    public void insertUangmuka (Integer isi){
        this.uangmuka.add(isi);
    }
    
    public ArrayList<Integer> getRecordUangmuka(){
        return this.uangmuka;
    }
    
}

