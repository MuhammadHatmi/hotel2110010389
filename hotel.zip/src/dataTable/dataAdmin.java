/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dataTable;

import java.util.ArrayList;

/**
 *
 * @author ACER
 */
public class dataAdmin {
    private ArrayList<Integer> kodeadmin;
    private ArrayList<String> username;
    private ArrayList<String> password;
    

    public dataAdmin(){
        
        kodeadmin = new ArrayList<Integer>();
        username = new ArrayList<String>();
        password = new ArrayList<String>();
       
    }
    
    public void insertKodeadmin(Integer isi){
        this.kodeadmin.add(isi);
    }
    
    public ArrayList<Integer> getRecordKodeadmin(){
        return this.kodeadmin;
    }
    
    public void insertUsername (String isi){
        this.username.add(isi);
    }
    
    public ArrayList<String> getRecordUsername(){
        return this.username;
    }
    
     
    public void insertPassword (String isi){
        this.password.add(isi);
    }
    
    public ArrayList<String> getRecordPassword(){
        return this.password;
    }
    

}
