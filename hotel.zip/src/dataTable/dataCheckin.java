/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dataTable;

import java.util.ArrayList;

/**
 *
 * @author ACER
 */
public class dataCheckin {
   
    private  ArrayList<Integer> notamu;
    private  ArrayList<Integer> noreg;
    private  ArrayList<Integer> nokamar;
    private  ArrayList<String> tglcheckin;
    private  ArrayList<String> jamcheckin;
    private  ArrayList<String> uangmuka;
    private  ArrayList<String> statusnota;

    public dataCheckin(){
        
        noreg = new ArrayList<Integer>();
        notamu = new ArrayList<Integer>();
        nokamar = new ArrayList<Integer>();
        tglcheckin = new ArrayList<String>();
        jamcheckin = new ArrayList<String>();
        uangmuka = new ArrayList<String>();
        statusnota = new ArrayList<String>();
        
    }
    
    public void insertNoreg(Integer isi){
        this.noreg.add(isi);
    }
    
    public ArrayList<Integer> getRecordNoreg(){
        return this.noreg;
    }
    
    public void insertNotamu (Integer isi){
        this.notamu.add(isi);
    }
    
    public ArrayList<Integer> getRecordNotamu(){
        return this.notamu;
    }
    
    public void insertNokamar(Integer isi){
        this.nokamar.add(isi);
    }
    
    public ArrayList<Integer> getRecordNokamar(){
        return this.nokamar;
    }
    
    public void insertTglcheckin (String isi){
        this.tglcheckin.add(isi);
    }
    
    public ArrayList<String> getRecordTglcheckin(){
        return this.tglcheckin;
    }
    
    public void insertJamcheckin (String isi){
        this.jamcheckin.add(isi);
    }
    
    public ArrayList<String> getRecordJamcheckin(){
        return this.jamcheckin;
    }
    
    public void insertUangmuka (String isi){
        this.uangmuka.add(isi);
    }
    
    public ArrayList<String> getRecordUangmuka(){
        return this.uangmuka;
    }
    
     public void insertStatusnota (String isi){
        this.statusnota.add(isi);
    }
    
    public ArrayList<String> getRecordStatusnota(){
        return this.statusnota;
    }
    

}
